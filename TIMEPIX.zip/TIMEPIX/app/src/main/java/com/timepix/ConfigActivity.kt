package com.timepix
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*

class ConfigActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, 0)
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
        val m = AppWidgetManager.getInstance(this)
        val type = m.getAppWidgetInfo(id).provider.className.last().toString()
        fun done() {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
            W.refresh(this); finish()
        }
        val list = Store.all(this).filter { it.type == type }
        val pend = Store.takePending(this)
        list.find { it.id == pend }?.let { Store.bind(this, id, it.id); done(); return }
        if (list.isEmpty()) { Toast.makeText(this, "Create a design in TIMEPIX first", Toast.LENGTH_LONG).show(); done(); return }
        val ll = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40); setBackgroundColor(Color.parseColor("#0E0E14")) }
        ll.addView(TextView(this).apply { text = "Pick a design"; textSize = 22f; setTextColor(Color.WHITE) })
        list.forEach { d -> ll.addView(Button(this).apply { text = d.title.ifEmpty { "Untitled" }; setOnClickListener { Store.bind(this@ConfigActivity, id, d.id); done() } }) }
        setContentView(ScrollView(this).apply { addView(ll) })
    }
}
