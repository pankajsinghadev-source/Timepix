package com.timepix
import android.appwidget.AppWidgetManager
import android.content.*
import org.json.*

data class Design(val id: String, val type: String, val title: String, val sub: String,
                  val target: Long, val img: String, val color: Int, val dim: Int)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("timepix", 0)
    fun all(c: Context): List<Design> {
        val a = JSONArray(p(c).getString("designs", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it)
            Design(o.getString("id"), o.getString("type"), o.getString("title"), o.getString("sub"),
                o.getLong("target"), o.getString("img"), o.getInt("color"), o.getInt("dim")) }
    }
    fun save(c: Context, l: List<Design>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("type", it.type).put("title", it.title).put("sub", it.sub)
            .put("target", it.target).put("img", it.img).put("color", it.color).put("dim", it.dim)) }
        p(c).edit().putString("designs", a.toString()).apply()
    }
    fun setPending(c: Context, id: String) = p(c).edit().putString("pending", id).apply()
    fun takePending(c: Context): String? { val id = p(c).getString("pending", null); p(c).edit().remove("pending").apply(); return id }
    fun bind(c: Context, wid: Int, did: String) = p(c).edit().putString("w$wid", did).apply()
    fun unbind(c: Context, wid: Int) = p(c).edit().remove("w$wid").apply()
    fun bound(c: Context, wid: Int): Design? { val id = p(c).getString("w$wid", null); return all(c).find { it.id == id } }
}

object W {
    val all = listOf(WidgetA::class.java, WidgetB::class.java, WidgetC::class.java, WidgetD::class.java)
    fun refresh(c: Context) {
        val m = AppWidgetManager.getInstance(c)
        all.forEach { cls ->
            val ids = m.getAppWidgetIds(ComponentName(c, cls))
            if (ids.isNotEmpty()) c.sendBroadcast(Intent(c, cls).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids))
        }
    }
}

class Refresh : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) = W.refresh(c) }
