package com.timepix
import android.app.*
import android.appwidget.*
import android.content.*
import android.graphics.*
import android.os.*
import android.widget.RemoteViews
import java.io.File

const val DAY = 86400000L

abstract class Base(private val layout: Int, private val countdown: Boolean) : AppWidgetProvider() {
    open fun tune(rv: RemoteViews, d: Design, rem: Long) {}
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = ids.forEach { render(c, m, it) }
    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: Bundle?) = render(c, m, id)
    override fun onDeleted(c: Context, ids: IntArray) = ids.forEach { Store.unbind(c, it) }

    fun render(c: Context, m: AppWidgetManager, id: Int) {
        val now = System.currentTimeMillis()
        val d = Store.bound(c, id) ?: Design("", "", "Open TIMEPIX", "Design me, then re-add", now, "", Color.WHITE, 40)
        val rem = maxOf(0L, d.target - now)
        val rv = RemoteViews(c.packageName, layout)
        rv.setTextViewText(R.id.title, d.title); rv.setTextViewText(R.id.sub, d.sub)
        for (v in intArrayOf(R.id.title, R.id.sub, R.id.num, R.id.days, R.id.sep, R.id.chrono, R.id.clock, R.id.date))
            rv.setTextColor(v, d.color)
        rv.setInt(R.id.dim, "setBackgroundColor", Color.argb(d.dim * 255 / 100, 0, 0, 0))
        if (d.img.isNotEmpty()) BitmapFactory.decodeFile(File(c.filesDir, d.img).path)?.let { rv.setImageViewBitmap(R.id.bg, it) }
        tune(rv, d, rem)
        rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        m.updateAppWidget(id, rv)
        if (countdown && rem > 0) { // wake exactly when the day count changes; no background service
            val pi = PendingIntent.getBroadcast(c, id, Intent(c, javaClass).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, intArrayOf(id)), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            c.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC, now + rem % DAY + 1000, pi)
        }
    }
}

class WidgetA : Base(R.layout.w_a, true) {
    override fun tune(rv: RemoteViews, d: Design, rem: Long) = rv.setTextViewText(R.id.num, (rem / DAY).toString())
}
class WidgetB : Base(R.layout.w_b, true) {
    override fun tune(rv: RemoteViews, d: Design, rem: Long) {
        rv.setTextViewText(R.id.days, "%02d".format(rem / DAY))
        rv.setChronometerCountDown(R.id.chrono, true) // native, ticks every second with no refresh cost
        rv.setChronometer(R.id.chrono, SystemClock.elapsedRealtime() + rem % DAY, null, rem > 0)
    }
}
class WidgetC : Base(R.layout.w_c, false)
class WidgetD : Base(R.layout.w_d, false)
