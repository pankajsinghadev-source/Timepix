package com.timepix
import android.app.*
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.util.*

class MainActivity : ComponentActivity() {
    private val types = listOf("A" to "A · Big number", "B" to "B · Cinematic", "C" to "C · Text & photo", "D" to "D · Clock")
    private val colors = listOf(Color.WHITE, Color.YELLOW, Color.CYAN, Color.parseColor("#C084FC"), Color.GREEN)
    private var ti = 0; private var ci = 0; private var img = ""; private var dim = 40
    private var cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 47) }
    private lateinit var imgBtn: Button; private lateinit var saved: LinearLayout
    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { u -> u?.let { img = saveImg(it); imgBtn.text = "Photo ✓ (tap to change)" } }

    private fun saveImg(u: Uri): String {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u).use { BitmapFactory.decodeStream(it, null, o) }
        val s = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1000)
        val bmp = contentResolver.openInputStream(u).use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }!!
        val k = 640f / maxOf(bmp.width, bmp.height) // keep small: RemoteViews has a binder size limit
        val out = if (k < 1) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
        val name = "img_${System.currentTimeMillis()}.jpg"
        File(filesDir, name).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        return name
    }

    private fun btn(t: String, f: (Button) -> Unit) = Button(this).apply { text = t; setOnClickListener { f(this) } }
    private fun et(h: String) = EditText(this).apply { hint = h; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val ll = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 90, 40, 60); setBackgroundColor(Color.parseColor("#0E0E14")) }
        ll.addView(TextView(this).apply { text = "TIMEPIX"; textSize = 32f; setTextColor(Color.parseColor("#8B5CF6")) })
        ll.addView(TextView(this).apply { text = "YOUR TIME. YOUR STYLE."; setTextColor(Color.parseColor("#3B82F6")) })
        val title = et("Title (e.g. COUNTDOWN)"); val sub = et("Subtitle")
        ll.addView(title); ll.addView(sub)
        ll.addView(btn("Layout: ${types[0].second}") { it.text = "Layout: ${types[++ti % 4].second}" })
        val dateBtn = btn("Target: ${"%tF %<tR".format(cal)}") { }
        dateBtn.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d -> cal.set(y, m, d)
                TimePickerDialog(this, { _, h, mi -> cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, mi); cal.set(Calendar.SECOND, 0)
                    dateBtn.text = "Target: ${"%tF %<tR".format(cal)}" }, 0, 0, true).show()
            }, cal[Calendar.YEAR], cal[Calendar.MONTH], cal[Calendar.DAY_OF_MONTH]).show()
        }
        ll.addView(dateBtn)
        imgBtn = btn("Pick background photo") { pick.launch("image/*") }; ll.addView(imgBtn)
        ll.addView(btn("Text colour (tap to cycle)") { ci++; it.setTextColor(colors[ci % colors.size]) })
        ll.addView(TextView(this).apply { text = "Darkness overlay"; setTextColor(Color.LTGRAY) })
        ll.addView(SeekBar(this).apply { progress = dim; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { dim = p }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {} }) })
        ll.addView(btn("SAVE & ADD TO HOME SCREEN") {
            val d = Design(UUID.randomUUID().toString(), types[ti % 4].first, title.text.toString(), sub.text.toString(),
                cal.timeInMillis, img, colors[ci % colors.size], dim)
            Store.save(this, Store.all(this) + d); Store.setPending(this, d.id); list(); pin(d.type)
        })
        saved = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; ll.addView(saved)
        setContentView(ScrollView(this).apply { addView(ll) }); list()
    }

    private fun pin(type: String) {
        val m = AppWidgetManager.getInstance(this)
        if (!m.isRequestPinAppWidgetSupported) { Toast.makeText(this, "Saved. Long-press Home > Widgets > TIMEPIX", Toast.LENGTH_LONG).show(); return }
        m.requestPinAppWidget(ComponentName(this, W.all["ABCD".indexOf(type)]), null, null)
    }

    private fun list() {
        saved.removeAllViews()
        saved.addView(TextView(this).apply { text = "\nSaved designs (tap to delete)"; setTextColor(Color.LTGRAY) })
        Store.all(this).forEach { d -> saved.addView(btn("${d.type} · ${d.title.ifEmpty { "Untitled" }}") {
            Store.save(this, Store.all(this).filter { it.id != d.id }); W.refresh(this); list() }) }
    }
}
